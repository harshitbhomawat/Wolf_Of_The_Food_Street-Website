from django.shortcuts import render, redirect, HttpResponseRedirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View


class Login(View):
    returnUrl = None

    def get(self, request):
        Login.returnUrl = request.GET.get('return_url')
        return render(request, 'loginPage.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        errorMessage = None
        if customer:
            if check_password(password, customer.password):
                request.session['customer'] = customer.id
                if Login.returnUrl:
                    return HttpResponseRedirect(Login.returnUrl)
                else:
                    Login.returnUrl = None
                    return redirect('homepage')
            else:
                errorMessage = "Email or password invalid!"
        else:
            errorMessage = "Email or password invalid!"
        return render(request, 'loginPage.html', {'error': errorMessage})


def logout(request):
    request.session.clear()
    return redirect('login')
# def loginPage(request):
#     if request.method == "GET":
#         return render(request, 'loginPage.html')
#     else:
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         customer = Customer.get_customer_by_email(email)
#         errorMessage = None
#         if customer:
#             if check_password(password, customer.password):
#                 return redirect('homepage')
#             else:
#                 errorMessage = "Email or password invalid!"
#         else:
#             errorMessage = "Email or password invalid!"
#         return render(request, 'loginPage.html', {'error': errorMessage})
