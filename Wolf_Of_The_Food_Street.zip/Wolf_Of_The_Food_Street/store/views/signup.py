from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):
    def validateCustomer(self, customer, confirmpass):
        errorMessage = None
        if customer.password != confirmpass:
            errorMessage = "confirm password doesn't match!"
        elif len(customer.password) < 6:
            errorMessage = "password must be 6 characters long!"
        elif len(customer.phone) < 10:
            errorMessage = "phone number can't be less than 10 digits long!"
        elif customer.city != "jaipur" and customer.city != "JAIPUR" and customer.city != "Jaipur" and customer.city != "jAIPUR" and customer.city != "JAipur":
            errorMessage = "Oops,We don't serve in the your city now!"
        elif customer.state == "Choose...":
            errorMessage = "Please select your state!"
        elif customer.isExists():
            errorMessage = "These Email is already registered!"
        return errorMessage

    def registerCustomer(self, request):
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        confirmpass = request.POST.get('confirmpass')
        address1 = request.POST.get('address1')
        address2 = request.POST.get('address2')
        city = request.POST.get('city')
        state = request.POST.get('state')
        zipcode = request.POST.get('zipcode')
        auth = request.POST.get('auth')

        value = {'name': name,
                 'email': email,
                 'phone': phone,
                 'password': password,
                 'confirmpass': confirmpass,
                 'address1': address1,
                 'address2': address2,
                 'zipcode': zipcode}

        customer = Customer(name=name,
                            email=email,
                            phone=phone,
                            password=password,
                            address1=address1,
                            address2=address2,
                            city=city,
                            state=state,
                            zipcode=zipcode,
                            auth=auth)

        errorMessage = self.validateCustomer(customer, confirmpass)

        if not errorMessage:
            customer.password = make_password(customer.password)
            customer.register()
            # return redirect('http://localhost:8000')
            # we are not using above method because, in this way we need to go to every place where we want to return or redirect to home page and write full url
            # instead we use name property in urls.py and use it everywhere.
            return redirect('homepage')

        else:
            data = {'error': errorMessage,
                    'values': value
                    }
            return render(request, 'signupPage.html', data)

    def get(self, request):
        return render(request, 'signupPage.html')

    def post(self, request):
        return self.registerCustomer(request)
# def signupPage(request):
#     if request.method == 'GET':
#         return render(request, 'signupPage.html')
#     if request.method == 'POST':
#         return registerCustomer(request)